

//Lizzy Andrews Project 3
#include <iostream>
#include "TrackerMap.h"
using namespace std;

int main() {
    TrackerMap cornerGrocer; //Creates an instance of TrackerMap class
    cornerGrocer.loadFile("CS210_Project_Three_Input_File.txt"); //Load data from input file

    int option = 0; // Initialize option to 0

    // Program loops until user enters "4"
    while (option != 4) {
        // Displays menu, prompts user to input an option, then stores input
        cornerGrocer.displayMenu();
        cout << "Enter an option: ";
        cin >> option;

        // Handles what to do based on what option user chooses
        switch (option) {
            // If user chose 1, search for item in the file
        case 1: {
            string searchItem;
            cout << "Enter the item name: ";
            cin >> searchItem;
            cornerGrocer.searchItem(searchItem);
            break;
        }
        case 2: {
            cornerGrocer.printFrequencyList();
            break;
        }
              // If user chose 3, print frequency histogram
        case 3: {
            cornerGrocer.printFrequencyHistogram();
            break;
        }
              // If user chose 4, end the program
        case 4:
            cout << "Program finished" << endl;
            break; // Ends the program
            // If user enters a number not from 1 - 4, display error message
        default:
            cout << "Not a valid choice" << endl;
        }
    }

    //Save item frequencies into an output file
    cornerGrocer.saveFile("frequency.dat");

    return 0;
}